# COMSCI ECON 206 Final Project Overleaf Template

Upload this ZIP to Overleaf or use it to update the team project shared through Canvas. Compile main.tex for the clean submission or annotated.tex for printable guidance. The class/style and bibliography files preserve the PS2 ACM layout. The clean main text is two A4 pages; Author Notes, references and Appendices A–G follow. Supporting material is unlimited.

Replace all prompts with your actual work. Remove unused authors. Keep the eight named main parts and a clearly named Future Research Roadmap subsection. Expand the three required diagrams in Appendix G when needed. Update BOTH paper and poster contributions and FULL acknowledgments. Preserve the prior PS2 auction and feedback records.

The final deadline is Wednesday, October 21, 2026, 23:00 Asia/Shanghai. Submit the clean paper PDF, complete source ZIP, editable A0 poster PPTX and poster PDF once per Canvas group. Supply the GitHub exact tested version, notebook, Hugging Face and root README poster URLs.

The actual poster preview and PDF must be committed to GitHub. Embed the preview and link the PDF in the repository ROOT README.md. Confirm this at the beginning of Oct 12 and Oct 14 and update it after each revision.

Local compilation: latexmk -pdf main.tex; latexmk -pdf annotated.tex. The ACM class files retain their upstream license notices. Templates provide guidance and placeholders, not completed research findings.
